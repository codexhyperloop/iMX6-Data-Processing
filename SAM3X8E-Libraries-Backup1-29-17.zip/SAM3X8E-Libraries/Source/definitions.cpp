/*
 * definitions.cpp
 *
 * Created: 12/9/2016 7:53:05 PM
 *  Author: codex
 */ 

